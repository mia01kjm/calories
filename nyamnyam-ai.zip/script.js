let currentFoodData = null;

function saveApiKey() {
  const key = document.getElementById("apiKeyInput").value;

  if (!key) {
    alert("API 키를 입력하세요!");
    return;
  }

  localStorage.setItem("gemini_api_key", key);

  document.getElementById("apiStatus").innerText =
    "✅ API 키 저장 완료!";
}

function quickSearch(food) {
  document.getElementById("foodInput").value = food;
  searchCalorie();
}

function getEmoji(food) {
  if (food.includes("라면")) return "🍜";
  if (food.includes("치킨")) return "🍗";
  if (food.includes("김밥")) return "🍙";
  if (food.includes("삼겹")) return "🥩";
  if (food.includes("떡")) return "🌶";
  if (food.includes("비빔밥")) return "🍚";
  return "🍽️";
}

async function searchCalorie() {
  const food = document.getElementById("foodInput").value.trim();

  if (!food) return;

  const apiKey = localStorage.getItem("gemini_api_key");

  if (!apiKey) {
    showError("먼저 API 키를 저장해주세요!");
    return;
  }

  hideError();

  document.getElementById("loading").classList.remove("hidden");
  document.getElementById("resultCard").classList.add("hidden");

  try {

    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + apiKey,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: `"${food}" 음식의 평균 영양 정보를 JSON 형식으로 알려줘.

반드시 아래 JSON 형식만 반환:
{
  "name":"",
  "desc":"",
  "calorie":0,
  "carb":0,
  "protein":0,
  "fat":0,
  "comment":""
}`
                }
              ]
            }
          ]
        })
      }
    );

    const data = await response.json();

    const text =
      data.candidates[0].content.parts[0].text;

    const cleanText = text
      .replace(/```json/g, "")
      .replace(/```/g, "")
      .trim();

    const result = JSON.parse(cleanText);

    currentFoodData = result;

    showResult(result);

  } catch (error) {
    console.error(error);
    showError("❌ AI 응답 오류가 발생했어요.");
  }

  document.getElementById("loading").classList.add("hidden");
}

function showResult(data) {

  document.getElementById("resEmoji").innerText =
    getEmoji(data.name);

  document.getElementById("resFoodName").innerText =
    data.name;

  document.getElementById("resFoodDesc").innerText =
    data.desc;

  document.getElementById("resCalorie").innerText =
    data.calorie;

  document.getElementById("resCarb").innerText =
    data.carb + "g";

  document.getElementById("resPro").innerText =
    data.protein + "g";

  document.getElementById("resFat").innerText =
    data.fat + "g";

  document.getElementById("resComment").innerText =
    data.comment;

  document.getElementById("resultCard")
    .classList.remove("hidden");
}

function saveToHistory() {

  if (!currentFoodData) return;

  let history =
    JSON.parse(localStorage.getItem("food_history")) || [];

  history.unshift(currentFoodData);

  localStorage.setItem(
    "food_history",
    JSON.stringify(history)
  );

  renderHistory();
}

function renderHistory() {

  const container =
    document.getElementById("historyContainer");

  let history =
    JSON.parse(localStorage.getItem("food_history")) || [];

  if (history.length === 0) {

    container.innerHTML =
      '<p class="empty">아직 기록이 없어요 🍽️</p>';

    return;
  }

  container.innerHTML = "";

  history.forEach(item => {

    const div = document.createElement("div");

    div.className = "history-item";

    div.innerHTML = `
      <h4>${getEmoji(item.name)} ${item.name}</h4>
      <p>${item.calorie} kcal</p>
    `;

    container.appendChild(div);
  });
}

function showError(msg) {

  const error = document.getElementById("errorMsg");

  error.innerText = msg;

  error.classList.remove("hidden");
}

function hideError() {

  document.getElementById("errorMsg")
    .classList.add("hidden");
}

renderHistory();
